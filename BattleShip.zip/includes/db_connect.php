<?php
    include_once 'db_connect.local.php';
// $servername = "localhost:3306";
// $username = "root";
// $password = "";
// $dbname = "Test";

// try {
//   $connect = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
//   $connect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
// } catch(PDOException $e) {
//   echo "Connection failed: " . $e->getMessage();
//   die();
// }

?>